This zip archive contains data files from Cricsheet in JSON format. This
archive contains 230 ICC Men's T20 World Cup matches. A further 29 matches
have been withheld due to either featuring the Afghanistan men's team or being
played in the Afghanistan Premier League, due to the Cricsheet policy to no
longer feature matches involving Afghanistan men or played in Afghanistan
Premier League (see https://cricsheet.org/withheld-matches for more
information).


The JSON data files contained in this zip file are version 1.2.0 files. You
can learn about the structure of these files at
https://cricsheet.org/format/json/


You can find the available downloads at https://cricsheet.org/downloads/, and
you can find the most up-to-date version of this zip file at
https://cricsheet.org/downloads/icc_mens_t20_world_cup_male_json.zip


The matches contained in this zip archive are listed below. The first field is
the start date of the match (for test matches or other multi-day matches), or
the actual date (for all other types of match). The second is the type of
teams involved, whether 'club', or 'international'. The third is the type of
match, either Test, ODI, ODM, T20, IT20, MDM, or a club competition code (such
as IPL). The 4th field is the gender of the players involved in the match. The
5th field is the id of the match, and the remainder of the line shows the
teams involved in the match.


2026-03-08 - international - T20 - male - 1512773 - India vs New Zealand
2026-03-05 - international - T20 - male - 1512772 - India vs England
2026-03-04 - international - T20 - male - 1512771 - South Africa vs New Zealand
2026-03-01 - international - T20 - male - 1512770 - West Indies vs India
2026-03-01 - international - T20 - male - 1512769 - Zimbabwe vs South Africa
2026-02-28 - international - T20 - male - 1512768 - Pakistan vs Sri Lanka
2026-02-27 - international - T20 - male - 1512767 - New Zealand vs England
2026-02-26 - international - T20 - male - 1512766 - India vs Zimbabwe
2026-02-26 - international - T20 - male - 1512765 - West Indies vs South Africa
2026-02-25 - international - T20 - male - 1512764 - New Zealand vs Sri Lanka
2026-02-24 - international - T20 - male - 1512763 - Pakistan vs England
2026-02-23 - international - T20 - male - 1512762 - West Indies vs Zimbabwe
2026-02-22 - international - T20 - male - 1512761 - South Africa vs India
2026-02-22 - international - T20 - male - 1512760 - England vs Sri Lanka
2026-02-20 - international - T20 - male - 1512758 - Oman vs Australia
2026-02-19 - international - T20 - male - 1512756 - Sri Lanka vs Zimbabwe
2026-02-19 - international - T20 - male - 1512755 - West Indies vs Italy
2026-02-18 - international - T20 - male - 1512754 - India vs Netherlands
2026-02-18 - international - T20 - male - 1512753 - Pakistan vs Namibia
2026-02-18 - international - T20 - male - 1512752 - United Arab Emirates vs South Africa
2026-02-17 - international - T20 - male - 1512751 - Scotland vs Nepal
2026-02-17 - international - T20 - male - 1512749 - Canada vs New Zealand
2026-02-16 - international - T20 - male - 1512748 - Australia vs Sri Lanka
2026-02-16 - international - T20 - male - 1512747 - England vs Italy
2026-02-15 - international - T20 - male - 1512745 - India vs Pakistan
2026-02-15 - international - T20 - male - 1512744 - United States of America vs Namibia
2026-02-15 - international - T20 - male - 1512743 - Nepal vs West Indies
2026-02-14 - international - T20 - male - 1512742 - New Zealand vs South Africa
2026-02-14 - international - T20 - male - 1512741 - Scotland vs England
2026-02-14 - international - T20 - male - 1512740 - Ireland vs Oman
2026-02-13 - international - T20 - male - 1512739 - United States of America vs Netherlands
2026-02-13 - international - T20 - male - 1512738 - Canada vs United Arab Emirates
2026-02-13 - international - T20 - male - 1512737 - Zimbabwe vs Australia
2026-02-12 - international - T20 - male - 1512736 - India vs Namibia
2026-02-12 - international - T20 - male - 1512735 - Nepal vs Italy
2026-02-12 - international - T20 - male - 1512734 - Sri Lanka vs Oman
2026-02-11 - international - T20 - male - 1512733 - West Indies vs England
2026-02-11 - international - T20 - male - 1512732 - Australia vs Ireland
2026-02-10 - international - T20 - male - 1512730 - Pakistan vs United States of America
2026-02-10 - international - T20 - male - 1512729 - United Arab Emirates vs New Zealand
2026-02-10 - international - T20 - male - 1512728 - Namibia vs Netherlands
2026-02-09 - international - T20 - male - 1512727 - South Africa vs Canada
2026-02-09 - international - T20 - male - 1512726 - Oman vs Zimbabwe
2026-02-09 - international - T20 - male - 1512725 - Scotland vs Italy
2026-02-08 - international - T20 - male - 1512724 - Sri Lanka vs Ireland
2026-02-08 - international - T20 - male - 1512723 - England vs Nepal
2026-02-07 - international - T20 - male - 1512721 - India vs United States of America
2026-02-07 - international - T20 - male - 1512720 - West Indies vs Scotland
2026-02-07 - international - T20 - male - 1512719 - Netherlands vs Pakistan
2024-06-29 - international - T20 - male - 1415755 - India vs South Africa
2024-06-27 - international - T20 - male - 1415754 - India vs England
2024-06-24 - international - T20 - male - 1415751 - India vs Australia
2024-06-23 - international - T20 - male - 1415750 - West Indies vs South Africa
2024-06-23 - international - T20 - male - 1415749 - United States of America vs England
2024-06-22 - international - T20 - male - 1415747 - India vs Bangladesh
2024-06-21 - international - T20 - male - 1415746 - United States of America vs West Indies
2024-06-21 - international - T20 - male - 1415745 - South Africa vs England
2024-06-20 - international - T20 - male - 1415744 - Bangladesh vs Australia
2024-06-19 - international - T20 - male - 1415742 - West Indies vs England
2024-06-19 - international - T20 - male - 1415741 - South Africa vs United States of America
2024-06-17 - international - T20 - male - 1415739 - Papua New Guinea vs New Zealand
2024-06-16 - international - T20 - male - 1415738 - Sri Lanka vs Netherlands
2024-06-16 - international - T20 - male - 1415737 - Bangladesh vs Nepal
2024-06-16 - international - T20 - male - 1415736 - Ireland vs Pakistan
2024-06-15 - international - T20 - male - 1415735 - Scotland vs Australia
2024-06-15 - international - T20 - male - 1415734 - England vs Namibia
2024-06-14 - international - T20 - male - 1415732 - Uganda vs New Zealand
2024-06-14 - international - T20 - male - 1415731 - South Africa vs Nepal
2024-06-13 - international - T20 - male - 1415728 - Oman vs England
2024-06-13 - international - T20 - male - 1415727 - Bangladesh vs Netherlands
2024-06-12 - international - T20 - male - 1415726 - West Indies vs New Zealand
2024-06-12 - international - T20 - male - 1415725 - United States of America vs India
2024-06-11 - international - T20 - male - 1415724 - Namibia vs Australia
2024-06-11 - international - T20 - male - 1415722 - Canada vs Pakistan
2024-06-10 - international - T20 - male - 1415721 - South Africa vs Bangladesh
2024-06-09 - international - T20 - male - 1415720 - Oman vs Scotland
2024-06-09 - international - T20 - male - 1415719 - India vs Pakistan
2024-06-08 - international - T20 - male - 1415718 - West Indies vs Uganda
2024-06-08 - international - T20 - male - 1415717 - Australia vs England
2024-06-08 - international - T20 - male - 1415716 - Netherlands vs South Africa
2024-06-07 - international - T20 - male - 1415715 - Sri Lanka vs Bangladesh
2024-06-07 - international - T20 - male - 1415713 - Canada vs Ireland
2024-06-06 - international - T20 - male - 1415712 - Namibia vs Scotland
2024-06-06 - international - T20 - male - 1415711 - Pakistan vs United States of America
2024-06-05 - international - T20 - male - 1415710 - Australia vs Oman
2024-06-05 - international - T20 - male - 1415709 - Papua New Guinea vs Uganda
2024-06-05 - international - T20 - male - 1415708 - Ireland vs India
2024-06-04 - international - T20 - male - 1415707 - Nepal vs Netherlands
2024-06-04 - international - T20 - male - 1415706 - Scotland vs England
2024-06-03 - international - T20 - male - 1415704 - Sri Lanka vs South Africa
2024-06-02 - international - T20 - male - 1415703 - Oman vs Namibia
2024-06-02 - international - T20 - male - 1415702 - Papua New Guinea vs West Indies
2024-06-01 - international - T20 - male - 1415701 - Canada vs United States of America
2022-11-13 - international - T20 - male - 1298179 - Pakistan vs England
2022-11-10 - international - T20 - male - 1298178 - India vs England
2022-11-09 - international - T20 - male - 1298177 - New Zealand vs Pakistan
2022-11-06 - international - T20 - male - 1298176 - India vs Zimbabwe
2022-11-06 - international - T20 - male - 1298175 - Bangladesh vs Pakistan
2022-11-06 - international - T20 - male - 1298174 - Netherlands vs South Africa
2022-11-05 - international - T20 - male - 1298173 - Sri Lanka vs England
2022-11-04 - international - T20 - male - 1298171 - New Zealand vs Ireland
2022-11-03 - international - T20 - male - 1298170 - Pakistan vs South Africa
2022-11-02 - international - T20 - male - 1298169 - India vs Bangladesh
2022-11-02 - international - T20 - male - 1298168 - Zimbabwe vs Netherlands
2022-11-01 - international - T20 - male - 1298167 - England vs New Zealand
2022-10-31 - international - T20 - male - 1298165 - Australia vs Ireland
2022-10-30 - international - T20 - male - 1298164 - India vs South Africa
2022-10-30 - international - T20 - male - 1298163 - Netherlands vs Pakistan
2022-10-30 - international - T20 - male - 1298162 - Bangladesh vs Zimbabwe
2022-10-29 - international - T20 - male - 1298161 - New Zealand vs Sri Lanka
2022-10-27 - international - T20 - male - 1298158 - Zimbabwe vs Pakistan
2022-10-27 - international - T20 - male - 1298157 - India vs Netherlands
2022-10-27 - international - T20 - male - 1298156 - South Africa vs Bangladesh
2022-10-26 - international - T20 - male - 1298154 - Ireland vs England
2022-10-25 - international - T20 - male - 1298153 - Sri Lanka vs Australia
2022-10-24 - international - T20 - male - 1298152 - Zimbabwe vs South Africa
2022-10-24 - international - T20 - male - 1298151 - Bangladesh vs Netherlands
2022-10-23 - international - T20 - male - 1298150 - Pakistan vs India
2022-10-23 - international - T20 - male - 1298149 - Ireland vs Sri Lanka
2022-10-22 - international - T20 - male - 1298147 - New Zealand vs Australia
2022-10-21 - international - T20 - male - 1298146 - Scotland vs Zimbabwe
2022-10-21 - international - T20 - male - 1298145 - West Indies vs Ireland
2022-10-20 - international - T20 - male - 1298144 - United Arab Emirates vs Namibia
2022-10-20 - international - T20 - male - 1298143 - Sri Lanka vs Netherlands
2022-10-19 - international - T20 - male - 1298142 - West Indies vs Zimbabwe
2022-10-19 - international - T20 - male - 1298141 - Scotland vs Ireland
2022-10-18 - international - T20 - male - 1298140 - Sri Lanka vs United Arab Emirates
2022-10-18 - international - T20 - male - 1298139 - Namibia vs Netherlands
2022-10-17 - international - T20 - male - 1298138 - Zimbabwe vs Ireland
2022-10-17 - international - T20 - male - 1298137 - Scotland vs West Indies
2022-10-16 - international - T20 - male - 1298136 - United Arab Emirates vs Netherlands
2022-10-16 - international - T20 - male - 1298135 - Namibia vs Sri Lanka
2021-11-14 - international - T20 - male - 1273756 - New Zealand vs Australia
2021-11-11 - international - T20 - male - 1273755 - Pakistan vs Australia
2021-11-10 - international - T20 - male - 1273754 - England vs New Zealand
2021-11-08 - international - T20 - male - 1273753 - Namibia vs India
2021-11-07 - international - T20 - male - 1273752 - Pakistan vs Scotland
2021-11-06 - international - T20 - male - 1273750 - South Africa vs England
2021-11-06 - international - T20 - male - 1273749 - West Indies vs Australia
2021-11-05 - international - T20 - male - 1273748 - Scotland vs India
2021-11-05 - international - T20 - male - 1273747 - New Zealand vs Namibia
2021-11-04 - international - T20 - male - 1273746 - Sri Lanka vs West Indies
2021-11-04 - international - T20 - male - 1273745 - Bangladesh vs Australia
2021-11-03 - international - T20 - male - 1273743 - New Zealand vs Scotland
2021-11-02 - international - T20 - male - 1273742 - Pakistan vs Namibia
2021-11-02 - international - T20 - male - 1273741 - Bangladesh vs South Africa
2021-11-01 - international - T20 - male - 1273740 - England vs Sri Lanka
2021-10-31 - international - T20 - male - 1273739 - India vs New Zealand
2021-10-30 - international - T20 - male - 1273737 - Australia vs England
2021-10-30 - international - T20 - male - 1273736 - Sri Lanka vs South Africa
2021-10-29 - international - T20 - male - 1273734 - West Indies vs Bangladesh
2021-10-28 - international - T20 - male - 1273733 - Sri Lanka vs Australia
2021-10-27 - international - T20 - male - 1273732 - Scotland vs Namibia
2021-10-27 - international - T20 - male - 1273731 - Bangladesh vs England
2021-10-26 - international - T20 - male - 1273730 - New Zealand vs Pakistan
2021-10-26 - international - T20 - male - 1273729 - West Indies vs South Africa
2021-10-24 - international - T20 - male - 1273727 - India vs Pakistan
2021-10-24 - international - T20 - male - 1273726 - Bangladesh vs Sri Lanka
2021-10-23 - international - T20 - male - 1273725 - West Indies vs England
2021-10-23 - international - T20 - male - 1273724 - South Africa vs Australia
2021-10-22 - international - T20 - male - 1273723 - Netherlands vs Sri Lanka
2021-10-22 - international - T20 - male - 1273722 - Ireland vs Namibia
2021-10-21 - international - T20 - male - 1273721 - Oman vs Scotland
2021-10-21 - international - T20 - male - 1273720 - Bangladesh vs Papua New Guinea
2021-10-20 - international - T20 - male - 1273719 - Sri Lanka vs Ireland
2021-10-20 - international - T20 - male - 1273718 - Netherlands vs Namibia
2021-10-19 - international - T20 - male - 1273717 - Bangladesh vs Oman
2021-10-19 - international - T20 - male - 1273716 - Scotland vs Papua New Guinea
2021-10-18 - international - T20 - male - 1273715 - Namibia vs Sri Lanka
2021-10-18 - international - T20 - male - 1273714 - Netherlands vs Ireland
2021-10-17 - international - T20 - male - 1273713 - Scotland vs Bangladesh
2021-10-17 - international - T20 - male - 1273712 - Papua New Guinea vs Oman
2016-04-03 - international - T20 - male - 951373 - England vs West Indies
2016-03-31 - international - T20 - male - 951371 - India vs West Indies
2016-03-30 - international - T20 - male - 951369 - England vs New Zealand
2016-03-28 - international - T20 - male - 951367 - South Africa vs Sri Lanka
2016-03-27 - international - T20 - male - 951363 - India vs Australia
2016-03-26 - international - T20 - male - 951361 - England vs Sri Lanka
2016-03-26 - international - T20 - male - 951359 - Bangladesh vs New Zealand
2016-03-25 - international - T20 - male - 951357 - South Africa vs West Indies
2016-03-25 - international - T20 - male - 951355 - Australia vs Pakistan
2016-03-23 - international - T20 - male - 951353 - India vs Bangladesh
2016-03-22 - international - T20 - male - 951349 - New Zealand vs Pakistan
2016-03-21 - international - T20 - male - 951347 - Australia vs Bangladesh
2016-03-20 - international - T20 - male - 951345 - Sri Lanka vs West Indies
2016-03-19 - international - T20 - male - 951341 - India vs Pakistan
2016-03-18 - international - T20 - male - 951339 - England vs South Africa
2016-03-18 - international - T20 - male - 951337 - Australia vs New Zealand
2016-03-16 - international - T20 - male - 951333 - Bangladesh vs Pakistan
2016-03-16 - international - T20 - male - 951331 - England vs West Indies
2016-03-15 - international - T20 - male - 951329 - India vs New Zealand
2016-03-13 - international - T20 - male - 951327 - Bangladesh vs Oman
2016-03-13 - international - T20 - male - 951325 - Ireland vs Netherlands
2016-03-12 - international - T20 - male - 951323 - Hong Kong vs Scotland
2016-03-11 - international - T20 - male - 951319 - Bangladesh vs Ireland
2016-03-10 - international - T20 - male - 951313 - Scotland vs Zimbabwe
2016-03-09 - international - T20 - male - 951311 - Ireland vs Oman
2016-03-09 - international - T20 - male - 951309 - Bangladesh vs Netherlands
2014-04-06 - international - T20 - male - 682965 - India vs Sri Lanka
2014-04-04 - international - T20 - male - 682963 - India vs South Africa
2014-04-03 - international - T20 - male - 682961 - Sri Lanka vs West Indies
2014-04-01 - international - T20 - male - 682959 - Pakistan vs West Indies
2014-04-01 - international - T20 - male - 682957 - Bangladesh vs Australia
2014-03-31 - international - T20 - male - 682955 - New Zealand vs Sri Lanka
2014-03-31 - international - T20 - male - 682953 - England vs Netherlands
2014-03-30 - international - T20 - male - 682951 - Australia vs India
2014-03-30 - international - T20 - male - 682949 - Bangladesh vs Pakistan
2014-03-29 - international - T20 - male - 682947 - England vs South Africa
2014-03-29 - international - T20 - male - 682945 - Netherlands vs New Zealand
2014-03-28 - international - T20 - male - 682943 - Bangladesh vs India
2014-03-28 - international - T20 - male - 682941 - Australia vs West Indies
2014-03-27 - international - T20 - male - 682939 - England vs Sri Lanka
2014-03-27 - international - T20 - male - 682937 - Netherlands vs South Africa
2014-03-25 - international - T20 - male - 682935 - Bangladesh vs West Indies
2014-03-24 - international - T20 - male - 682933 - Netherlands vs Sri Lanka
2014-03-24 - international - T20 - male - 682931 - New Zealand vs South Africa
2014-03-23 - international - T20 - male - 682929 - India vs West Indies
2014-03-23 - international - T20 - male - 682927 - Australia vs Pakistan
2014-03-22 - international - T20 - male - 682925 - England vs New Zealand
2014-03-22 - international - T20 - male - 682923 - South Africa vs Sri Lanka
2014-03-21 - international - T20 - male - 682921 - India vs Pakistan
2014-03-21 - international - T20 - male - 682919 - Ireland vs Netherlands
2014-03-21 - international - T20 - male - 682917 - United Arab Emirates vs Zimbabwe
2014-03-20 - international - T20 - male - 682915 - Bangladesh vs Hong Kong
2014-03-19 - international - T20 - male - 682911 - Ireland vs United Arab Emirates
2014-03-19 - international - T20 - male - 682909 - Netherlands vs Zimbabwe
2014-03-18 - international - T20 - male - 682907 - Bangladesh vs Nepal
2014-03-17 - international - T20 - male - 682903 - Netherlands vs United Arab Emirates
2014-03-17 - international - T20 - male - 682901 - Ireland vs Zimbabwe
2014-03-16 - international - T20 - male - 682899 - Hong Kong vs Nepal
